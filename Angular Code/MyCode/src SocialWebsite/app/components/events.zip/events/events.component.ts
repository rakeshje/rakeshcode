import { Component, OnInit, HostListener } from '@angular/core';
import { ServerService } from 'src/app/services/server.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormControlName } from '@angular/forms';
import { INgxMyDpOptions, IMyDateModel } from 'ngx-mydatepicker';
import { Observable, Subject } from 'rxjs';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

declare var $:any;
@Component({
    selector: 'app-events',
    templateUrl: './events.component.html',
    styleUrls: ['./events.component.scss']
})
export class EventsComponent implements OnInit {
    selected: any='All Events';
    myOptions: INgxMyDpOptions = {
      dateFormat: 'd/m/yyyy',
      todayBtnTxt: 'Today',
      sunHighlight: true,
      disableUntil: {year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate()}
    };
    total: number;
    addEventForm: FormGroup;
    type: any;
    base64Image: any="assets/images/Layer 139.png";
    upload: any;
    addEventDetails: any;
    filterBy: any="";
    videoUrl: string;
    eventList: any=[];
    pageNo: any= 1;
    limit: any=10;
    eventLocationArr: any=[];
    length: any;
    search: any="";
    myPostedEventsArr: any=[];
    cloudinaryUrl: any="assets/images/Layer 139.png";
    obj:any={}
    eventId: any;
    commentsArr: any=[];
    likesArr: any=[];
    searchTerm$ = new Subject<string>();
    selectedIndex:any
    commentInterval: any;
    myId: any;
    likeInterval: any;
    apiHit:boolean= true;

    constructor(public server:ServerService, private router:Router) { 
      // to get my id
      this.myId = localStorage.getItem('user_id')
      window.scrollTo(0,0)

      // to add search filter
      this.server.search(this.searchTerm$)
      .subscribe(results => {
        this.search = results;
        this.getMyPostedEvents()
      });
    }

    ngOnInit() {
      this.checkValidAddEventForm()
      this.callByUrl()     
    }

    ngOnDestroy() {
      clearInterval(this.commentInterval)
      clearInterval(this.likeInterval)
    }

    // to get event location
    getEventLocation() {
      this.server.postApi('user/eventLocation',{}).subscribe((res)=> {
        this.eventLocationArr = res.result;
      })
    }

    // to call by Url
    callByUrl()  {
      let arr = window.location.href.split('/')
      let val = arr[arr.length - 1]
      this.selectTab(val)
    }

    // to check tab
    selectTab(path) {
      window.scrollTo(0,0)
      this.selected = path;
      this.eventList = [];
      this.myPostedEventsArr =[];
      this.commentsArr = [];
      this.likesArr= []
      this.cloudinaryUrl = ''
      this.router.navigateByUrl('events/' + path)
      this.pageNo = 1
      this.total = 0
      this.search = "";
      if(path == 'All_Events') {
        this.getEventsList();
        this.getEventLocation();
      } else if(path == 'View_My_Posted_Events') {
          this.getMyPostedEvents()
      }       
    }

    //to check validity */
    checkValidAddEventForm() {
      this.addEventForm = new FormGroup({
        eventTitle: new FormControl('', [Validators.required]),
        eventDescription: new FormControl('',[Validators.required]),
        eventLocation: new FormControl('', [Validators.required]),
        eventDate: new FormControl('', [Validators.required]),
        eventTime: new FormControl('00:00',),
      })
    }

    /** to get the value of Add Event form field  */
    get eventTitle(): any {
      return this.addEventForm.get('eventTitle');
    }
    get eventDescription(): any {
      return this.addEventForm.get('eventDescription');
    }
    get eventLocation(): any {
      return this.addEventForm.get('eventLocation');
    }
    get eventDate(): any {
      return this.addEventForm.get('eventDate');
    }
    get eventTime(): any {
      return this.addEventForm.get('eventTime');
    }

    /** To upload cover picture of Event */
    handleFileInput(event) {
      var self = this;
      if(event.target.files && event.target.files[0]){
        this.type = event.target.files[0].type;
        console.log(this.type)
        if(this.type === 'video/mp4' || this.type === 'video/mov' || this.type === 'video/flv' || this.type === 'image/png' || this.type === 'image/jpg' || this.type === 'image/jpeg') { 
          var reader = new FileReader()
          reader.onload = (e)=> {
            this.base64Image = e.target['result'];
            let mb = 1000000;
            let size = ((event.target.files[0]['size'])/mb)
            if(this.type === 'video/mp4' || this.type === 'video/mov' || this.type === 'video/flv') {
              if(size <= 50) {
                this.uploadFile()
              }else {
                this.server.showErrToast('Size must be less than 50 MB')
                return;
              }
            }else if(this.type === 'image/png' || this.type === 'image/jpg' || this.type === 'image/jpeg') {
              if(size <= 10) {
                this.uploadFile()
              }else {
                this.server.showErrToast('Size must be less than 10 MB')
                return;
              }
            }
            }
          reader.readAsDataURL(event.target.files[0]);
        } else {
            this.server.showErrToast("Select only mp4,mov or flv file.");
          }
      }
    }

    // to uplaod file
    uploadFile() {
      this.cloudinaryUrl=';'
      // to upload image and video
      let data={}, url ;
      if (this.type === 'image/png' || this.type === 'image/jpg') {
        this.base64Image = this.base64Image.substring(22);
      } else if (this.type === 'image/jpeg') {
        this.base64Image = this.base64Image.substring(23);
      }   

      if(this.type === 'image/png' || this.type === 'image/jpg' || this.type === 'image/jpeg') {
        data['profilePic'] =  'data:'+ this.type +'/;base64,'+this.base64Image;
        url ='user/imageUpload/'
      }else if(this.type === 'video/mp4' || this.type === 'video/mov' || this.type === 'video/flv') {
        data['video'] = this.base64Image;
        url = 'user/videoUpload'
      }

      if(navigator.onLine) {
        let api = this.server.postApi(url,data).subscribe((res)=>{
          this.cloudinaryUrl = res.result
          console.log(this.cloudinaryUrl)
        })
      }
    }

    //To add events
    addEvent(){
      if(!this.cloudinaryUrl) {
        this.server.showErrToast('Please upload video or image')
        return;
      }
      let data={
        "userId": localStorage.getItem('user_id'),
        "title": this.addEventForm.value.eventTitle,
        "description": this.addEventForm.value.eventDescription,
        "location": this.addEventForm.value.eventLocation,
        "date":this.addEventForm.value.eventDate.formatted,
        "time": this.addEventForm.value.eventTime,
      }

      if(this.type === 'image/png' || this.type === 'image/jpg' || this.type === 'image/jpeg') {
        data['image'] =  this.cloudinaryUrl
      }else {
        console.log(this.base64Image)
        data['videoBase'] = this.cloudinaryUrl
      }
      // to check internet connection
      if(navigator.onLine) {
        this.addEventDetails = this.server.postApi('user/addEvent', data).subscribe((res)=> {
            this.addEventDetails.unsubscribe()
            if(res.responseCode == 200) {
              this.addEventForm.reset();
              this.server.showSuccToast('Event Posted!')  
            }
        })    
      }
    }

    // to add
    addFilter(val) {
      this.filterBy = val
      this.eventList = []
      this.getEventsList();
    }

    // to get event list
    getEventsList() {
      let data = {
        "userId": localStorage.getItem('user_id'),
        "newsDay":this.filterBy,
        "pageNumber": this.pageNo,
        "limit": this.limit,
        "search": this.search
      }
      
      if(navigator.onLine) {
        this.server.postApi('user/viewEvent', data).subscribe((res)=> {
          if(res.responseCode == 200) {
            let result = res.result.docs;
            result.forEach(element => {
              element['dynamicClass'] = "hide-clas none"
              if(element.likes.length > 0) {
                element.likes.forEach(element2 => {
                  if(element2['likedId'] == localStorage.getItem('user_id')) {
                    element['myLike']= true
                  }else {
                    element['myLike']= false
                  }
                })
              }
              this.eventList.push(element)
            });
          
            console.log(this.eventList)
            this.length = this.eventList.length
          }
        })
      }
    }

    // to change location
    changeLocation(selected_location) {
      this.search = selected_location
      this.eventList = []
      this.getEventsList()
    }

    // to toggle list
    showList(index) {
      if(this.eventList[index]['dynamicClass']= "hide-clas none") {
        this.eventList[index]['dynamicClass']="hide-clas"
      }else if(this.eventList[index]['dynamicClass']= "hide-clas") {
        this.eventList[index]['dynamicClass']="hide-clas none"
      }
    }

    showHide(index) {
      if(this.commentsArr[index]['dynamicClass']= "hide-clas none") {
        this.commentsArr[index]['dynamicClass']="hide-clas"
      }else if(this.commentsArr[index]['dynamicClass']= "hide-clas") {
        this.commentsArr[index]['dynamicClass']="hide-clas none"
      }
    }

    // to hidde delete 
    actionOnEventList() {
      // api here
    }

    //  api for my p[osted events
    getMyPostedEvents() {
      let data = {
        "userId": localStorage.getItem('user_id'),
        "search": this.search,
        "limit": this.limit,
        "pageNumber": this.pageNo
      }
      if(navigator.onLine) {
        this.server.postApi('user/myEvent', data).subscribe((res)=>{
          if(res.responseCode == 200) {
            let result = res.result.docs
            result.forEach(element => {
              element['dynamicClass'] = "hide-clas none"
              this.myPostedEventsArr.push(element)
            });
            this.total= this.myPostedEventsArr.length
          }
        })
      }
    }

    // to get event on scroll End(bottom of the page)
    @HostListener("window:scroll", [])
    onScroll(): void {
    if ((window.innerHeight + window.scrollY ) >= document.body.offsetHeight) {
        console.log('bottom reached!',window.innerHeight + window.scrollY  + ' >= ' + (document.body.offsetHeight))
            // you're at the bottom of the page
            this.pageNo ++;
            console.log('length of event Arr', this.eventList.length)
            this.callOnScroll()
          }  
    }

    // to call on scroll
    callOnScroll() {
      let arr = window.location.href.split('/')
      let path = arr[arr.length - 1]
      if(path!= 'Add_Events') {
        if(path == 'All_Events') {
          this.getEventsList();
        } else if(path == 'View_My_Posted_Events') {
            this.getMyPostedEvents()
        }   
      }else {
        return;
      }
    }

    // to open comments modal
    openCommentModal(data) {
      this.eventId = data['_id']
      this.viewLikesComments(data,'comments')
      this.commentInterval = setInterval(()=>{
        this.viewLikesComments(data,'comments')
      },60000)
    }

    // to open likes modal
    openLikesModal(data) {
      if(data.likes.length>0) {
        this.eventId = data['_id']
        this.viewLikesComments(data,'likes')
        this.likeInterval = setInterval(()=>{
          this.viewLikesComments(data,'likes')
        },60000)
      }
    }

    // to view likes and comments
    viewLikesComments(data,show) {
      let req = {
        "userId":data['userId']['_id'],
        "eventId":data['_id'],
        "show":show
      }
      if(navigator.onLine && this.apiHit) {
        this.apiHit = false
        let api =this.server.postApi('user/viewEventsLikesAndComment', req).subscribe((res)=> {
          this.apiHit = true
          api.unsubscribe();  
          console.log(res.comments)
          if(show == 'comments') {
            if(this.selected == 'All_Events') {
              let index = this.eventList.findIndex((x)=>x==data)
              this.selectedIndex = index
              this.eventList[index]['comments'] = res.comments
            }else if(this.selected == 'View_My_Posted_Events') {
              let index = this.myPostedEventsArr.findIndex((x)=>x==data)
              this.selectedIndex= index;
              this.myPostedEventsArr[index]['comments'] = res.comments
            }
            // to open modal
            $('#exampleModalCenter').modal({backdrop: 'static', keyboard: false}) 
            res.comments.forEach((element)=>{
              element['dynamicClass'] = "hide-clas none"
            })
            this.commentsArr = res.comments
          }else if(show == 'likes') {
            if(this.selected == 'All_Events') {
              let index = this.eventList.findIndex((x)=>x==data)
              this.selectedIndex = index
              this.eventList[index]['likes'] = res.likes
            }else if(this.selected == 'View_My_Posted_Events') {
              let index = this.myPostedEventsArr.findIndex((x)=>x==data)
              this.selectedIndex= index;
              this.myPostedEventsArr[index]['likes'] = res.likes
            }
            // to open modal
            $('#likedmodal').modal({backdrop: 'static', keyboard: false}) 
            // for managing add button
            res.likes.forEach((element)=> {
              element['add_button']= true
            })
            this.likesArr = res.likes
            console.log('ARRAY LIKES',this.likesArr)
          }
        })
      }
    }

    // to add comment to event
    addComment() { 
      if(this.obj.comment) {
        let data = {
          "userId": localStorage.getItem('user_id'),
          "eventId": this.eventId,
          "comment": this.obj.comment,
          "comments":"true",
        }
        if(navigator.onLine && this.apiHit) {
          this.apiHit = false
          let api = this.server.postApi('user/eventLikeAndComment',data).subscribe((res)=>{
            this.apiHit = true
            api.unsubscribe()
            if(res.responseCode == 200) {
              this.obj.comment =''
              this.server.showSuccToast('Comment added');
              if(this.selected == 'All_Events') {
                console.log(res.comments.comments[res.comments.comments.length - 1])
                this.eventList[this.selectedIndex]['comments'] = res.comments.comments
                this.commentsArr = res.comments.comments;
              }else if(this.selected == 'View_My_Posted_Events') {
                this.myPostedEventsArr[this.selectedIndex]['comments'] = res.comments.comments
                this.commentsArr = res.comments.comments
              }
            }
          })
        }
      }else{
        return;
      }
    }

    /** to check space */
    toCheckSpace(evt){
      var charCode = (evt.which) ? evt.which : evt.keyCode;
      console.log(charCode)
      if(charCode == 32 && !evt.target.value) {
        evt.preventDefault()
      }else {
        return true;
      }
    }
    
    // to like event
    addLikeEvent(data,val) {
      this.eventId = data['_id']
      let index = this.eventList.findIndex(x=>x == data)
      this.selectedIndex = index
      console.log(index)
      if(navigator.onLine && this.apiHit) {
        this.apiHit = false
        let data = {
          "userId": localStorage.getItem('user_id'),
          "eventId": this.eventId,
          "like": val
        }
        this.server.postApi('user/eventLikeAndComment',data).subscribe((res)=>{
          this.apiHit = true
          if(res.responseCode == 200) {
            if(val == 'true') {
              this.server.showSuccToast('Liked!')
              if(this.selected == 'All_Events') {
                this.eventList[this.selectedIndex]['likes'] = res.likes
                this.likesArr = res.likes;

                this.eventList[this.selectedIndex]['myLike'] = true
              }else if(this.selected == 'View_My_Posted_Events') {
                this.myPostedEventsArr[this.selectedIndex]['likes'] = res.likes
                this.likesArr = res.likes;
                this.eventList[this.selectedIndex]['myLike'] = true
              }
            }else if(val == 'false'){
              this.server.showSuccToast('UnLiked!')
              if(this.selected == 'All_Events') {
                this.eventList[this.selectedIndex]['likes'] = res.result.likes
                this.likesArr = res.result.likes;
                this.eventList[this.selectedIndex]['myLike'] = false
              }else if(this.selected == 'View_My_Posted_Events') {
                this.myPostedEventsArr[this.selectedIndex]['likes'] = res.result.likes
                this.likesArr = res.result.likes;
                this.eventList[this.selectedIndex]['myLike'] = false
              }
              console.log(this.eventList[this.selectedIndex])
            }
          }
        })
      }
    }

    // to delete comment 
    deleteComment() {

    }

    // on close modal
    closeModal() {
      clearInterval(this.commentInterval);
      clearInterval(this.likeInterval);
      this.commentsArr = [];
      this.likesArr= []
    }

     // to add / remove friend in a list from suggestion
     addFriend(id) {
      let data = {
          "friendId": id,
          "response": 'SENT'
      }
      if(navigator.onLine) {
          let add_friend = this.server.postApi('user/sendFriendRequest',data).subscribe((res)=> {
              add_friend.unsubscribe()
              if(res.responseCode == 200) {
                  this.server.showSuccToast(res.responseMessage)
                  let index = this.likesArr.findIndex(x=>x['likedId'] == id);
                  this.likesArr[index]['add_button'] = false
                  
              }
          })
      }else {
          this.server.showWarnToast('Check internet connection!')
      }
  }
}